# Jerry package

This package was created to work in tandum with NetworkX graph objects. The main goal of the package was to give a faster way to run a randomized Kruskal and randomized Wilson's algorithm on NetworkX objects. With the implementations that we have here, we see ~5-6x speed improvement over the native NetworkX method.

## Installation
The installation of this library is based around installing a wheel file for python. This will be the mose difficut to do on Windows machines, but Macintosh and Linux should be relatively simple

### Windows

### MacOS

### Linux